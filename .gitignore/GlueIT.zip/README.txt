Hcomsoft GlueIT 1.0 

by Hugo Ariel Galan Menchaca

********************************************
Version History

V 1.0 28/JUL/2018 (release date)

Core using .NET 2.0

I did this project because I really loved the program originally created by Yves Plouffe.

He did an excellent job, but he did not have options for Blender Game Engine (BGE)

The new option added is "Down to UP"

Greetings community Blender.





